<?php
  $conexion=mysql_connect("localhost","root","");
  $baseDeDatos=mysql_select_db("agenda",$conexion);
?>
