<div id="footer">
	<p>My Photos Online</p>
	<p>Design by Free CSS Templates <a href='http://www.freecsstemplates.org'>www.freecsstemplates.org</a></p>
</div>