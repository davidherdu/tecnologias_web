<?php
include("conexion.php");
include("cabecera.php");
//manejamos en sesion el nombre del usuario que se ha logeado
if((!isset($_SESSION["usuario"]))||($_SESSION["usuario"]!=$_SESSION["user"])){
    header("location:index.php");
}
else{
	$usuario = mysqli_real_escape_string($_SESSION["conexion"],$_SESSION["usuario"]);
	$q_foto = mysqli_real_escape_string($_SESSION["conexion"],$_GET["foto"]); 
	$q_aux = mysqli_real_escape_string($_SESSION["conexion"],$_GET["aux"]); 
	$sqlFoto = "DELETE FROM foto WHERE tituloFoto = '$q_aux'";
	mysqli_query($_SESSION["conexion"],$sqlFoto) or exit('Datos de foto incorrectos.');

	@unlink($q_foto);

	header("location:listaFotosEliminar.php");
}
?>

