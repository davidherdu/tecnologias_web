<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html" />
<meta content="charset=utf-8" />
<title>My Photos Online</title>
<link href="http://fonts.googleapis.com/css?family=Abel|Arvo" rel="stylesheet" type="text/css" />
<link href="estilo/style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="estilo/login.css" rel="stylesheet" type="text/css" media="screen" />
<link href="estilo/vanadium.css" rel="stylesheet" type="text/css" media="screen" />
<link href="estilo/juqery-ui.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="javascript/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="javascript/jquery.dropotron-1.0.js"></script>
<script type="text/javascript" src="javascript/jquery.slidertron-1.0.js"></script>
<script type="text/javascript" src="javascript/jquery.poptrox-1.0.js"></script>
<script type="text/javascript" src="javascript/vanadium.js"></script>
<script type="text/javascript" src="javascript/login.js"></script>
<script type="text/javascript" src="javascript/funciones.js"></script>
<script type="text/javascript">
	$('#menu').dropotron();
	
	$(document).ready(function() {
		$('#showlogin').click(function() {
		  $('#loginpanel').slideToggle('slow', function() {
			  $("#triangle_down").toggle(); 
			  $("#triangle_up").toggle();
		  });
		});
	 });
	 
	$(document).ready(function(){
		$("#comentario").focus();
		$("#boton").click(function(){
			$("#comenta").append("<li>" + $("#comentario").val() + "</li>");
			$("#comentario).val("").focus();
		});
	});
</script>
</head>
<body style="background: url(images/main.jpg) repeat;">
	<div id="wrapper">
		<div id="header-wrapper" style="height: 200px;">
			<div id="header">
				<div id="menu-wrapper" style="width: relative;">
					<ul id="menu">
						<li><a href="usuario.php"><span>David Hernandez</span></a></li>
						<li><a href="albumes.php"><span>Albumes</span></a></li>
						<li><a href="grupo.php"><span>Grupos</span></a></li>
						<li><a href="listaAmigos.php"><span>Amigos</span></a></li>
						<li><div id="loginContainer">
							<a href="#" id="loginButton"><span>Invitacion</span><em></em></a>
							<div style="clear:both"></div>
								<div id="loginBox">                
									<form id="loginForm"action="usuario.php" method="post">
										<fieldset id="body">
											<fieldset>
												<label for="email">Email</label>
												<input type="text" name="email" id="email" class=":required" title="Introduce el correo"/>
											</fieldset>
											<input type="submit" id="login" value="Invitar" />
										</fieldset>
									</form>
								</div>
							</div>	
						</li>
						<li><a href="logout.php"><span>Salir</span></a></li>
					</ul>
				</div>
				<div id="logo">
					<h1>fotos de david hernandez</h1>
				</div>
			</div>		
			<!-- end #menu -->
			<!-- start -->
		</div>
		<div id="page">
			<div id="foto">
				<div id="imagen">
					<img src="images/india1.jpg" width="613" height="400" alt="" />
				</div>
				<div id="comentarios">
					<div id="textos">
						<ul id="comenta">
							<li>Juan: como mola esta foto</li>
							<li>Carmen: si mola mucho,donde fue hecha?</li>
							<li>Yo: en la India</li>
							<li>Carmen: en serio?!?!?!?</li>
							<li>Carmen: has estado alli?</li>
							<li><form name="comentar" action="#" method="post" id="texto"/>
									<dt>Escribe un comentario:</dt>
									<textarea id="comentario" name="coment" cols="33" ></textarea>
									<input type="submit" id="boton" name="publicar" style="width:100px;" tabindex="6" value="Publicar" onclick="actualizaFoto()"/>
								</form>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- end #header -->
		</div>
	</div>
	<br/><br/><br/><br/><br/><br/><br/><br/><br/>
	<div id="footer">
		<p>My Photos Online</p>
		<p>Design by Free CSS Templates <a href='http://www.freecsstemplates.org'>www.freecsstemplates.org</a></p>
	</div>
	<!-- end #footer -->
</body>
</html>
